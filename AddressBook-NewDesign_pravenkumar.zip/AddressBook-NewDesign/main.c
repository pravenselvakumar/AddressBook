/*
Documentation:
Name: Pravenkumar S
ID  : 26012_007
Start Date: 17-07-2026
End Date:28-07-2026
Description: Address Book Management System: Created a C-based Contact Management System that manages contacts with 
             add, search, edit, delete, and sort operations. Implemented file handling for permanent data storage.
Sample i/p:

========== Address Book Menu ==========
1. Create Contact
2. Search Contact
3. Edit Contact
4. Delete Contact
5. List All Contacts
6. Exit
Sample o/p: 
Enter your choice  : 1

Sample output   : 
Enter your choice  : 1

Enter Name         : praven

Enter Phone Number : 7418529630

Enter Email        : praven@gmail.com

Contact Created Successfully
*/

#include <stdio.h>
#include "contact.h"

int main() {
    int choice;
    AddressBook addressBook;
    initialize(&addressBook); // Initialize the address book

    do {
        printf("\n-----Address Book Menu-----\n");
        printf("1. Create contact\n");
        printf("2. Search contact\n");
        printf("3. Edit contact\n");
        printf("4. Delete contact\n");
        printf("5. List all contacts\n");
        printf("6. Save & Exit\n");
        printf("---------------------------\n");
        printf("Enter your choice: ");
        if(scanf("%d", &choice)!=1)//if the condition check the input value is in the choice or not
        {
            printf("Invalid choice! Please try again.\n");
            while(getchar()!='\n');
            continue;
        }
        
        switch (choice) {
            case 1:
                createContact(&addressBook);//function call for creatcontact
                break;
            case 2:
                printf("---------------------------\n");
                printf("Select Search criteria:\n");
                printf("1. Search by name\n");
                printf("2. Search by phone\n");
                printf("3. Search by email\n");
                printf("4. Exiting Search\n");
                printf("---------------------------\n");
                printf("Enter your choice: ");
                int SearchChoice;//
                //scanf("%d", &SearchChoice);
                   if(scanf("%d", &SearchChoice)!=1)//if the condition check the input value is in the choice or not
        {
            printf("Invalid choice! Please try again.\n");
            while(getchar()!='\n');
            
            continue;
        }
                searchContact(&addressBook, SearchChoice);//funtion call for search contacts
                break;
            case 3:
            
                editContact(&addressBook);//funtion call for edit contacts
                break;
            case 4:
                deleteContact(&addressBook);//funtion call for delete contacts
                break;
            case 5:
             printf("---------------------------\n");
                printf("Select sort criteria:\n");
                printf("1. Sort by name\n");
                printf("2. Sort by phone\n");
                printf("3. Sort by email\n");
                printf("4.Exit\n");
                 printf("---------------------------\n");
                printf("Enter your choice: ");
                int sortChoice;
                //scanf("%d", &sortChoice);
                   if(scanf("%d", &sortChoice)!=1)//if the condition check the input value is in the choice or not
        {
            printf("Invalid choice! Please try again.\n");
            while(getchar()!='\n');
            continue;
        }
                listContacts(&addressBook, sortChoice);//funtion call for sorting contacts
                break;
            case 6:
                printf("Saving and Exiting...\n");
                saveContactsToFile(&addressBook);//funtion call for save the contacts
                break;
            default:
                printf("Invalid choice. Please try again.\n");
        }
    } while (choice != 6);
    
       return 0;
}
