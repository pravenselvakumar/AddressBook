#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "contact.h"
#include "file.h"
#include "populate.h"

void listContacts(AddressBook *addressBook, int sortCriteria) //function for Sorting
{
    // Sort contacts based on the chosen criteria
    switch(sortCriteria)
    {
        case 1:
        printf("Sorting based on name:\n");
        for(int i=0;i<addressBook->contactCount-1;i++)//outer loop shows the number for passing values
        {
            for(int j=0;j<addressBook->contactCount -i -1;j++)// inner loop compare the values
            {
                if(strcmp(addressBook->contacts[j].name,addressBook->contacts[j+1].name)>0)//here it compare the two names
                {
                    Contact temp = addressBook->contacts[j];
                    addressBook->contacts[j]=addressBook->contacts[j+1];
                    addressBook->contacts[j+1]=temp;
                }
            }
        }
        printf("Index\t\tname\t\tphone\t\temail\n");
        for(int i=0;i<addressBook->contactCount;i++)//this for loop for printing the sorting by name
        {
            printf("%d\t%s\t%s\t%s\n",i+1,addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
        }
        break ;
        case 2:
        printf("Sorting based on Phone:\n");
        for(int i=0;i<addressBook->contactCount-1;i++)//outer loop shows the number for passing values
        {
            for(int j=0;j<addressBook->contactCount-i-1;j++)// inner loop compare the values
            {
                if(strcmp(addressBook->contacts[j].phone,addressBook->contacts[j+1].phone)>0)//here it compare the two Phone numbers
                {
                    Contact temp = addressBook->contacts[j];
                    addressBook->contacts[j]=addressBook->contacts[j+1];
                    addressBook->contacts[j+1]=temp;
                }
            }
        }
        printf("Index\t\tname\t\tphone\t\temail\n");
        for(int i=0;i<addressBook->contactCount;i++)//this for loop for printing the sorting by Phone
        {
            printf("%d\t%s\t%s\t%s\n",i+1,addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
        }
        break ;
        case 3:
        printf("Sorting based on email:\n");
        for(int i=0;i<addressBook->contactCount-1;i++)//outer loop shows the number for passing values
        {
            for(int j=0;j<addressBook->contactCount-i-1;j++)// inner loop compare the values
            {
                if(strcmp(addressBook->contacts[j].email,addressBook->contacts[j+1].email)>0)//here it compare the two Emails
                {
                    Contact temp = addressBook->contacts[j];
                    addressBook->contacts[j]=addressBook->contacts[j+1];
                    addressBook->contacts[j+1]=temp;
                }
            }
        }
        printf("Index\t\tname\t\tphone\t\temail\n");
        for(int i=0;i<addressBook->contactCount;i++)//this for loop for printing the sorting by Email
        {
            printf("%d\t%s\t%s\t%s\n",i+1,addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
        }
        break ;
        case 4:
        printf("Exit\n");
        break;
        default:
         printf("Invalid choice. Please try again.\n");
    }
    
}

void initialize(AddressBook *addressBook)//this function for file loaded
 {
    addressBook->contactCount = 0;
    //populateAddressBook(addressBook);
    
    // Load contacts from file during initialization (After files)
    loadContactsFromFile(addressBook);//load the create contact
}

void saveAndExit(AddressBook *addressBook) //this function for to save and exit the contact
{
    saveContactsToFile(addressBook); // Save contacts to filez
    exit(EXIT_SUCCESS); // Exit the program
}


void createContact(AddressBook *addressBook)//the function for create the contact
{
	char name[50];
    char phone[20];
    char email[50];
    int valid;
    
    

    // For check the contact is full or not
     if(addressBook->contactCount >= MAX_CONTACTS)
    {
        printf("Address Book Full\n");
        return;
    }
    printf("Press 0 to Exit the operation\n");
    do{
        valid=1;
    //for name
    
    printf("Enter the name :");
    scanf(" %[^\n]",name);
       if (strcmp(name, "0") == 0)//this condition for cancle the operation
    {
        printf("Operation cancelled.\n");
        return;
    }
    for(int i=0;name[i];i++)
    {
        if(!((name[i]>='A'&& name[i]<='Z')||
             (name[i]>='a'&& name[i]<='z')||
             (name[i]==' ')))//if statement for the alphabets should in A to Z or a to z or ( ) whitespace
        {
            printf("Error: Name should contain only alphabets\n ");
            valid=0;
            break;
        }

    }
    if(strlen(name)<3)// if statement for the name should contaion atleast 3 letters
    {
        printf("Error: Name must contain atleast 3 characters\n");
        valid=0;
    }
}while(valid==0);//this do while statement for if give the wrong input for the name. it stay in the content does not exit the loop
    //for phone number
    do{
        valid=1;

    printf("Enter the number:");
    scanf(" %[^\n]",phone);
    for(int i=0;phone[i];i++)
    {
        if(!(phone[i]>='0' && phone[i]<='9'))//if statement for the phone should be in the value of 0 to 9
        {
            printf("Other than Digits any other Character not allowed in phone number\n");
            valid=0;
            break;
        }
    }
    if(strlen(phone)!=10)//phone number should contain 10 numbers
    {
        printf("Phone number must contain exactly 10 digits\n");
        valid=0;
       
    }
    if(!(phone[0]>='6'&& phone[0]<='9'))// this condtion for the first number should be  6 to 9
    {
        printf("First digit must be between 6 and 9\n");
        valid=0;
        
    }
    for(int i=0;i<addressBook->contactCount;i++)
    {
        if(!(strcmp(phone,addressBook->contacts[i].phone)))// in this condition we check the phone number already register or not
        {
            printf("Phone number already exists\n");
            valid=0;
            break;
        }
    }
    }while(valid==0);//this do while statement for if give the wrong input for the phone. it stay in the content does not exit the loop
    // For email vaildation
    do
{
    valid = 1;

    int at = 0, dot = 0;
    int atPos = -1, dotPos = -1;

    printf("Enter the Email: ");
    scanf(" %[^\n]", email);

    
    for(int i = 0; email[i] != '\0'; i++)
    {
        if(email[i] >= 'A' && email[i] <= 'Z')//if statement for to check the value in uppercase or not
        {
            printf("Error: Email should contain only lowercase letters and digits\n");
            valid = 0;
            break;
        }

        if((email[i] >= 'a' && email[i] <= 'z') ||
           (email[i] >= '0' && email[i] <= '9'))//if statem for the values should be in lowercase or numbers
            continue;

        if(email[i] == '@')// if statement for  @ want to present in mail id 
        {
            at++;
            atPos = i;
        }
        else if(email[i] == '.') //if statement for  . want to present in mail id 
        {
            dot++;
            dotPos = i;
        }
        else
        {
            printf("Error: Invalid symbol\n");
            valid = 0;
            break;
        }
    }

    if(valid == 0)
        continue;

    
    if(at == 0)//if statement for  to check the one @ is present or not
    {
        printf("Error: Missing @\n");
        valid = 0;
        continue;
    }

    if(at > 1)// if statement for count of @
    {
        printf("Error: Multiple @ symbols are not allowed\n");
        valid = 0;
        continue;
    }

    
    if(dot == 0)//if statement for  to check the one . is present or not
    {
        printf("Error: Missing .\n");
        valid = 0;
        continue;
    }

    if(dot > 1)// if statement for count of .
    {
        printf("Error: Multiple dots are not allowed\n");
        valid = 0;
        continue;
    }

   
    if(dotPos < atPos)//if statement for . should appear after the @
    {
        printf("Error: . must appear after @\n");
        valid = 0;
        continue;
    }

    
    if(dotPos - atPos <= 1)//if statement for the atleast one character should be present in between @ and .
    {
        printf("Error: There must be at least one character between @ and .\n");
        valid = 0;
        continue;
    }

   
    if(strcmp(email + dotPos, ".com") != 0)//if statement for the after the .com there no values 
    {
        printf("Error: Extra characters after the domain or invalid domain\n");
        valid = 0;
        continue;
    }

    
    for(int i = 0; i < addressBook->contactCount; i++)
    {
        if(strcmp(email, addressBook->contacts[i].email) == 0)//condition for to camapre the email id to check the email already exit or not
        {
            printf("Error: Email already exists\n");
            valid = 0;
            break;
        }
    }

} while(valid == 0);//this do while statement for if give the wrong input for the email. it stay in the content does not exit the loop


    int i=addressBook->contactCount;
    sscanf(name,"%s",addressBook->contacts[i].name);
    sscanf(phone,"%s",addressBook->contacts[i].phone);
    sscanf(email,"%s",addressBook->contacts[i].email);

    addressBook->contactCount++;
    printf("Contact creat Successfully");//here store the value in addressbook and increase the contactcount values
    
}

void searchContact(AddressBook *addressBook,int SearchChoice ) //function for search the contacts
{
    int count =0;
    char str[100];
    switch(SearchChoice)
    {
        case 1:

        printf("Enter the name :");
        scanf(" %[^\n]",str);
        for(int i=0;i<addressBook->contactCount;i++)
        {
         if((strcasestr(addressBook->contacts[i].name,str))!=NULL)//condition for to check the input name present in address book or not
         {
            printf("\t%s\t%s\t%s\n",addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
            count=1;
         }
        }
        if(!(count))
        {
            printf("Result Not Found");
        }
        break;
        case 2:

        printf("Enter the Phone Number :");
        scanf(" %[^\n]",str);
        if(strlen(str) != 10)//condtion for  to check phone contains 10 number or not
        {
            printf("Invalid Phone Number.\n");
            break;
        }
        for(int i=0;i<addressBook->contactCount;i++)
        {
         if((strcasestr(addressBook->contacts[i].phone,str))!=NULL)//condition for to check the input phone present in address book or not
         {
            printf("\t%s\t%s\t%s\n",addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
            count=1;
         }
        }
        if(!(count))
        {
            printf("Result Not Found");
        }
        break;
        case 3:

        printf("Enter the Email :");
        scanf(" %[^\n]",str);
        if(strchr(str, '@') == NULL)
        {
            printf("Invalid Email ID.\n");
            break;
        }
        for(int i=0;i<addressBook->contactCount;i++)
        {
         if((strcasestr(addressBook->contacts[i].email,str))!=NULL)//condition for to check the input email present in address book or not
         {
            printf("\t%s\t%s\t%s\n",addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
            count=1;
         }
        }
        if(!(count))
        {
            printf("Result Not Found");
        }
        break;
        case 4:
            printf("Exiting Search.\n");//exti from the operation
            return;
        default:
         printf("Invalid choice. Please try again.\n");

        
    }
}

void editContact(AddressBook *addressBook)
{
	int count =0,choice;
    char str[100];
    char ename[50];
    char ephone[50];
    char eemail[50];
    int valid;
    printf("---------------------------\n");
    printf("Select your option\n");
    printf("1.Edit by name:\n");
    printf("2.Edit by Phonenumber:\n");
    printf("3.Edit by email:\n");
    printf("4.Exit\n");
     printf("---------------------------\n");
    printf("Enter the choice:");
    //scanf(" %d",&choice);
       if(scanf("%d", &choice)!=1)
        {
            printf("Invalid choice! Please try again.\n");
            while(getchar()!='\n');
            
            return;
        }
    switch(choice)
    {
        case 1:
        
      
         count=0;
        printf("Enter the name :");
        scanf(" %[^\n]",str);
        for(int i=0;i<addressBook->contactCount;i++)
        {
         if((strcasestr(addressBook->contacts[i].name,str))!=NULL)
         {
            printf("\t%s\t%s\t%s\n",addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
            do{
         valid = 1;
            printf("Enter the name for Edit:");
            scanf(" %[^\n]",ename);
             for(int i=0;ename[i];i++)
    {
        if(!((ename[i]>='A'&& ename[i]<='Z')||
             (ename[i]>='a'&& ename[i]<='z')||
             (ename[i]==' ')))//if statement for the alphabets should in A to Z or a to z or ( ) whitespace
        {
            printf("Error: Name should contain only alphabets\n ");
            valid=0;
            break;
        }

    }
    if(strlen(ename)<3)// if statement for the name should contaion atleast 3 letters
    {
        printf("Error: Name must contain atleast 3 characters\n");
        valid=0;
    }
        }while(valid==0);//this do while statement for if give the wrong input for the phone. it stay in the content does not exit the loop

           
    
            if(valid)
{
    strcpy(addressBook->contacts[i].name, ename);
    printf("Contact Update successfully.");
}
            count=1;
            break;
         }
        }
        if(!(count))
        {
            printf("Result Not Found");
        }
        break;
        case 2://edit for phone number
        

       count=0;
        printf("Enter the Phone Number :");
        scanf(" %[^\n]",str);
        for(int i=0;i<addressBook->contactCount;i++)
        {
         if((strcasestr(addressBook->contacts[i].phone,str))!=NULL)
         {
            printf("\t%s\t%s\t%s\n",addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
            do{
       valid=1;
            printf("Enter the Phone number for Edit:");
            scanf(" %[^\n]",ephone);
            for(int i=0;ephone[i];i++)
    {
        if(!(ephone[i]>='0' && ephone[i]<='9'))//if statement for the phone should be in the value of 0 to 9
        {
            printf("Other than Digits any other Character not allowed in phone number\n");
            valid=0;
            break;
        }
    }
    if(strlen(ephone)!=10)//phone number should contain 10 numbers
    {
        printf("Phone number must contain exactly 10 digits\n");
        valid=0;
       
    }
    if(!(ephone[0]>='6'&& ephone[0]<='9'))// this condtion for the first number should be  6 to 9
    {
        printf("First digit must be between 6 and 9\n");
        valid=0;
        
    }
    for(int i=0;i<addressBook->contactCount;i++)
    {
        if(!(strcmp(ephone,addressBook->contacts[i].phone)))// in this condition we check the phone number already register or not
        {
            printf("Phone number already exists\n");
            valid=0;
            break;
        }
    }
        }while(valid == 0);

            
  
            if(valid)
{
    strcpy(addressBook->contacts[i].phone, ephone);
    printf("Contact Update successfully.");
}
            count=1;
            break;
         }
        }
        if(!(count))
        {
            printf("Result Not Found\n");
        }
        
    break;
        case 3://edit for mail
        
        
              count=0;

    

        printf("Enter the Email :");
        scanf(" %[^\n]",str);
        for(int i=0;i<addressBook->contactCount;i++)
        {
         if((strcasestr(addressBook->contacts[i].email,str))!=NULL)
         {
            printf("\t%s\t%s\t%s\n",addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
            do{
              valid = 1;
              int at = 0, dot = 0;
              int atPos = -1, dotPos = -1;
            printf("Enter the email for Edit:");
            scanf(" %[^\n]",eemail);
            for(int i = 0; eemail[i] != '\0'; i++)
    {
        if(eemail[i] >= 'A' && eemail[i] <= 'Z')//if statement for to check the value in uppercase or not
        {
            printf("Error: Email should contain only lowercase letters and digits\n");
            valid = 0;
            break;
        }

        if((eemail[i] >= 'a' && eemail[i] <= 'z') ||
           (eemail[i] >= '0' && eemail[i] <= '9'))//if statem for the values should be in lowercase or numbers
            continue;

        if(eemail[i] == '@')// if statement for  @ want to present in mail id 
        {
            at++;
            atPos = i;
        }
        else if(eemail[i] == '.') //if statement for  . want to present in mail id 
        {
            dot++;
            dotPos = i;
        }
        else
        {
            printf("Error: Invalid symbol\n");
            valid = 0;
            break;
        }
    }

    if(valid == 0)
        continue;

    
    if(at == 0)//if statement for  to check the one @ is present or not
    {
        printf("Error: Missing @\n");
        valid = 0;
        continue;
    }

    if(at > 1)// if statement for count of @
    {
        printf("Error: Multiple @ symbols are not allowed\n");
        valid = 0;
        continue;
    }

    
    if(dot == 0)//if statement for  to check the one . is present or not
    {
        printf("Error: Missing .\n");
        valid = 0;
        continue;
    }

    if(dot > 1)// if statement for count of .
    {
        printf("Error: Multiple dots are not allowed\n");
        valid = 0;
        continue;
    }

   
    if(dotPos < atPos)//if statement for . should appear after the @
    {
        printf("Error: . must appear after @\n");
        valid = 0;
        continue;
    }

    
    if(dotPos - atPos <= 1)//if statement for the atleast one character should be present in between @ and .
    {
        printf("Error: There must be at least one character between @ and .\n");
        valid = 0;
        continue;
    }

   
    if(strcmp(eemail + dotPos, ".com") != 0)//if statement for the after the .com there no values 
    {
        printf("Error: Extra characters after the domain or invalid domain\n");
        valid = 0;
        continue;
    }

    
    for(int i = 0; i < addressBook->contactCount; i++)
    {
        if(strcmp(eemail, addressBook->contacts[i].email) == 0)//condition for to camapre the email id to check the email already exit or not
        {
            printf("Error: Email already exists\n");
            valid = 0;
            break;
        }
    }
            }while(valid==0);//this do while statement for if give the wrong input for the phone. it stay in the content does not exit the loop

           if(valid)
{
    strcpy(addressBook->contacts[i].email, eemail);
    printf("Contact Update successfully.");
}
            count=1;
            break;
         }
        }
        if(!(count))
        {
            printf("Result Not Found");
        }
        break;
        case 4:
        printf("Exit\n");
        break;
        default:
         printf("Invalid choice. Please try again.\n");
        
    }

    
    
}


void deleteContact(AddressBook *addressBook)
{
	
   
    int choice, count = 0;
    char str[100];
    char confirm;
     printf("---------------------------\n");
     printf("Select your option\n");
    printf("1. Delete by Name\n");
    printf("2. Delete by Phone Number\n");
    printf("3. Delete by Email\n");
    printf("4. Exit\n");
 printf("---------------------------\n");
    printf("Enter your choice: ");
    //scanf("%d", &choice);
       if(scanf("%d", &choice)!=1)// condition for check  the value should in the choice or not
        {
            printf("Invalid choice! Please try again.\n");
            while(getchar()!='\n');
            return;
        }

    switch(choice)
    {
        case 1:
            printf("Enter the Name: ");
            scanf(" %[^\n]", str);

            for(int i = 0; i < addressBook->contactCount; i++)
            {
                if(strcasestr(addressBook->contacts[i].name, str) != NULL)//condition for to check the input name present in address book or not
                {
                    printf("\nContact Found:\n");
                    printf("\t%s\t%s\t%s\n",addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);
                    printf("\nDelete this contact? (y/n): ");//statement for confirm to delete the contact
                    scanf(" %c", &confirm);

                    if(confirm == 'y' || confirm == 'Y')
                    {
                        for(int j = i; j < addressBook->contactCount - 1; j++)//statement for the delete the contact and resize the index value
                        {
                            addressBook->contacts[j] = addressBook->contacts[j + 1];
                        }

                        addressBook->contactCount--;
                        printf("Contact deleted successfully.\n");
                    }
                    else
                    {
                        printf("Deletion cancelled.\n");
                    }

                    count = 1;
                    break;
                }
            }
            break;

        case 2:
            printf("Enter the Phone Number: ");
            scanf(" %[^\n]", str);

            for(int i = 0; i < addressBook->contactCount; i++)
            {
                if(strcmp(addressBook->contacts[i].phone, str) == 0)//condition for to check the input phone present in address book or not
                {
                    printf("\nContact Found:\n");
                    printf("\t%s\t%s\t%s\n",addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);


                    printf("\nDelete this contact? (y/n): ");//statement for confirm to delete the contact
                    scanf(" %c", &confirm);

                    if(confirm == 'y' || confirm == 'Y')
                    {
                        for(int j = i; j < addressBook->contactCount - 1; j++)//statement for the delete the contact and resize the index value
                        {
                            addressBook->contacts[j] = addressBook->contacts[j + 1];
                        }

                        addressBook->contactCount--;
                        printf("Contact deleted successfully.\n");
                    }
                    else
                    {
                        printf("Deletion cancelled.\n");
                    }

                    count = 1;
                    break;
                }
            }
            break;

        case 3:
            printf("Enter the Email: ");
            scanf(" %[^\n]", str);

            for(int i = 0; i < addressBook->contactCount; i++)
            {
                if(strcmp(addressBook->contacts[i].email, str) == 0)//condition for to check the input email present in address book or not
                {
                    printf("\nContact Found:\n");
                    printf("\t%s\t%s\t%s\n",addressBook->contacts[i].name,addressBook->contacts[i].phone,addressBook->contacts[i].email);


                    printf("\nDelete this contact? (y/n): ");//statement for confirm to delete the contact
                    scanf(" %c", &confirm);

                    if(confirm == 'y' || confirm == 'Y')
                    {
                        for(int j = i; j < addressBook->contactCount - 1; j++)//statement for the delete the contact and resize the index value
                        {
                            addressBook->contacts[j] = addressBook->contacts[j + 1];
                        }

                        addressBook->contactCount--;
                        printf("Contact deleted successfully.\n");
                    }
                    else
                    {
                        printf("Deletion cancelled.\n");
                    }

                    count = 1;
                    break;
                }
            }
            break;
            case 4:
            printf("Exit");
            break;

        default:
            printf("Invalid Choice\n");
            return;
    }

    if(count == 0)
    {
        printf("Contact not found.\n");
    }
}
    
   
