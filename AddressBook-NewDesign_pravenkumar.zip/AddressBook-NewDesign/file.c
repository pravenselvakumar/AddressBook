#include <stdio.h>
#include <unistd.h>
#include "file.h"

void saveContactsToFile(AddressBook *addressBook)
{
    FILE *fptr;

    if ((fptr = fopen("contact.csv", "w")) == NULL)//creat the new files to store the data
    {
        fprintf(stderr, "File not found\n");
        return;
    }

    for (int i = 0; i < addressBook->contactCount; i++)//loop run the every contact to store the value
    {
        fprintf(fptr, "%s,%s,%s\n",
                addressBook->contacts[i].name,
                addressBook->contacts[i].phone,
                addressBook->contacts[i].email);
    }

    fclose(fptr);// to close the file
   // for Animation
    for (int i = 0; i <= 100; i++)// this loop run upto 0 to 100 time
    {
        printf("Saving [");

        for (int dash = 0; dash < i; dash++)
            printf("-");

        for (int space = 0; space < 100 - i; space++)// this loop for print the remaing space to print the ----
            printf(" ");

        printf("] %d%%\r", i);

        fflush(stdout);

        usleep(30000);   // 30 milliseconds
    }

    printf("\nContacts saved successfully.\n");
}
void loadContactsFromFile(AddressBook *addressBook)
{
    FILE *fptr;

    if ((fptr = fopen("contact.csv", "r")) == NULL)//this statement for read the file 
    {
        fprintf(stderr, "File not found\n");
        return;
    }

    addressBook->contactCount = 0;

    while (addressBook->contactCount < MAX_CONTACTS &&
           fscanf(fptr,
                  "%[^,],%[^,],%[^\n]\n",
                  addressBook->contacts[addressBook->contactCount].name,
                  addressBook->contacts[addressBook->contactCount].phone,
                  addressBook->contacts[addressBook->contactCount].email) == 3)// it checks the maximum count and store and read the value
    
        addressBook->contactCount++;//count increment
    

    fclose(fptr);
}
